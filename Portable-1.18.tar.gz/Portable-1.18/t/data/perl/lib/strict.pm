This is a placeholder for the Perl executable
